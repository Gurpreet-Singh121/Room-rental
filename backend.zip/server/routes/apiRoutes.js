const router = require('express').Router()
const helper = require('../utilities/helpers')


//controllers
const userController = require('../apis/user/userController')

const roomController = require('../apis/room/roomController')
const cityController = require('../apis/city/cityController') 
const roomtypeController = require('../apis/roomType/roomTypeController') 
const resellerController = require('../apis/reseller/resellerController') 
const roombookingController = require('../apis/roomBooking/roombookingController')
const enquiryController = require('../apis/enquiry/enquiryController')
const dashboardController = require('../apis/dashboard/dashboardController')

//auth=
router.post('/user/login', userController.login)


//user
router.post('/user/add', helper.uploadImageFun.single('user_image'), userController.addUser)


//city
router.post('/city/all', cityController.getAll)
router.post('/city/single', cityController.getSingle)

//roomtype
router.post('/roomtype/all', roomtypeController.getAll)
router.post('/roomtype/single', roomtypeController.getSingle)

//reseller
router.post('/reseller/all', resellerController.getAll)
router.post('/reseller/single', resellerController.getSingle)


//room
router.post('/room/all', roomController.getAll)
router.post('/room/single', roomController.getSingle)



router.use(require('../middleware/tokenChecker'))

//dashboard
router.get('/dashboard', dashboardController.dashboard)

//city
router.post('/city/add', helper.uploadImageFun.single('city_image'), cityController.addCity)
router.post('/city/update', helper.uploadImageFun.single('city_image'), cityController.updateCity)
router.post('/city/delete', cityController.delete)

//room type
router.post('/roomtype/add', roomtypeController.addRoomType)
router.post('/roomtype/update', roomtypeController.updateRoomType)
router.post('/roomtype/delete', roomtypeController.delete)

//reseller
router.post('/reseller/add', helper.uploadImageFun.single('reseller_image'), resellerController.addReseller)
router.post('/reseller/update', helper.uploadImageFun.single('reseller_image'), resellerController.updateReseller)
router.post('/reseller/delete', resellerController.delete)

//buyer
router.post('/user/update',  helper.uploadImageFun.single('user_image'),userController.updateUser)
router.post('/user/all', userController.getAll)
router.post('/user/single', userController.getSingle)
router.post('/user/delete', userController.delete)

//room
router.post('/room/add', helper.uploadImageFun.fields([{name:"room_image1"},{name:"room_image2"}]),   roomController.addRoom)
router.post('/room/update', helper.uploadImageFun.fields([{name:"room_image1"},{name:"room_image2"}]), roomController.updateRoom)
router.post('/room/delete', roomController.delete)

//roombooking
router.post('/roombooking/add', roombookingController.addRoombooking)
router.post('/roombooking/updateStatus', roombookingController.updateRoombookingStatus)
router.post('/roombooking/all', roombookingController.getAll)
router.post('/roombooking/single', roombookingController.getSingle)

//enquiry
router.post('/enquiry/all', enquiryController.getAll)
router.post('/enquiry/single', enquiryController.getSingle)
router.post('/enquiry/add', enquiryController.addEnquiry)



router.all('*', (req, res) => {
    res.send({
        success: false,
        status: 404,
        message: "Invalid Address"
    })
})

module.exports = router