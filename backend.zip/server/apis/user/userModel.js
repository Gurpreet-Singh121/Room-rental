const mongoose = require('mongoose')
const userSchema = mongoose.Schema({
    userId: { type: Number, default: 0 },
    name: { type: String, default: "" },
    contact: { type: String, default: "" },
    gender: { type: String, default: "" },
    image: { type: String, default: "user/default.jpg" },
    email: { type: String, default: "" },
    password: { type: String, default: "" },
    userType: { type: Number, default: 2 },// 1=> Admin, 2=> Buyer
    status: { type:Boolean, default:false},
    createdAt: { type: Date, default: Date.now }

})


const User = module.exports = mongoose.model('user', userSchema)
