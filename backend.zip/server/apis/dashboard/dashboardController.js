const User = require('../user/userModel')
const City = require('../city/cityModel')
const Roomtype = require('../roomType/roomtypeModel')
const Reseller = require('../reseller/resellerModel')
const Room = require('../room/roomModel')
const Roombooking = require('../roomBooking/roombookingModel')
const Enquiry = require('../enquiry/enquiryModel')


exports.dashboard = async (req, res) => {
    let totalBuyers = await User.find({ userType: 2 })
    let totalCities = await City.countDocuments()
    let totalRoomtypes = await Roomtype.countDocuments()
    let totalResellers = await Reseller.countDocuments()
    let totalRooms = await Room.countDocuments()
    let totalRoombookings = await Roombooking.countDocuments()
    let totalEnquiries = await Enquiry.countDocuments()
    res.send({ success: true, status: 200, totalRoomtypes: totalRoomtypes, totalResellers: totalResellers, totalRooms:totalRooms, totalRoombookings:totalRoombookings, totalEnquiries: totalEnquiries, totalBuyers: totalBuyers.length, totalCities: totalCities })
}

