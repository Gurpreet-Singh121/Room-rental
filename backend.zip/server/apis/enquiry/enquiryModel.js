const mongoose = require('mongoose')
const enquirySchema = mongoose.Schema({
    enquiryId: { type: Number, default: 0 },
    
    name: { type: String, default: "" },
    email: { type: String, default: "" },
    contact: { type: String, default: "" },
    subject: { type: String, default: "" },
    message: { type: String, default: "" },

    createdAt: { type: Date, default: Date.now }

})



const enquiry = module.exports = mongoose.model('enquiry', enquirySchema)