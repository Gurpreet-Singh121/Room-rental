const Enquiry = require('./enquiryModel')
const helper = require('../../utilities/helpers')


exports.getAll = async (req, resp) => {
    await Enquiry.find(req.body).then(res => {
            resp.send({ success: true, status: 200, message: "All Enquiries loaded", data: res })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
}



exports.getSingle = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Enquiry.findOne(query)
            .then(res => {
                if (!!res) {
                    resp.send({ success: true, status: 200, message: "Enquiry loaded Successfully", data: res })
                }
                else
                    resp.send({ success: false, status: 404, message: "No Enquiry Found" })
            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })
    }


}



exports.addEnquiry = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData.name)
        validation += "name is required,"
    if (!formData.email)
        validation += "email is required,"
    if (!formData.contact)
        validation += "contact is required,"
    if (!formData.subject)
        validation += "subject is required,"
    if (!formData.message)
        validation += "message is required,"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
            let total = await Enquiry.countDocuments()
            let enquiryData = {
                enquiryId : total+1,
                name: formData.name,
                email: formData.email,
                contact: formData.contact,
                subject: formData.subject,
                message: formData.message
            }
            let enquiry = new Enquiry(enquiryData)
            enquiry.save().then(res => {
                resp.send({ success: true, status: 200, message: "Enquiry added Successfully", data: res })
            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })

        // }
    }
}
