const RoomType = require('./roomtypeModel')
const helper = require('../../utilities/helpers')


exports.getAll = async (req, resp) => {
    await RoomType.find(req.body).then(res => {
        resp.send({ success: true, status: 200, message: "All Room types loaded", data: res })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })
}



exports.getSingle = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })

    let query = { _id: formData._id }
    await RoomType.findOne(query).then(res => {
        if (!!res) {
            resp.send({ success: true, status: 200, message: "Room Type loaded Successfully", data: res })
        }
        else
            resp.send({ success: false, status: 404, message: "No RoomType Found" })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })

}



exports.addRoomType = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData.name)
        validation += "name is required,"


    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let total = await RoomType.countDocuments()
        let roomtypeData = {
            roomtypeId: total + 1,
            name: formData.name
        }
        let roomtype = new RoomType(roomtypeData)
        let prevRoomType = await RoomType.findOne({ name: formData.name })
        if (prevRoomType)
            resp.send({ success: false, status: 409, message: "RoomType already exists with same name" })
        else
            roomtype.save().then(res => {
                resp.send({ success: true, status: 200, message: "RoomType added Successfully", data: res })

            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })
    }


}



exports.updateRoomType = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await RoomType.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.name)
                    res.name = formData.name
                let id = res._id
                let prevRoomType = await RoomType.findOne({ $and: [{ name: res.name }, { _id: { $ne: id } }] })
                if (prevRoomType)
                    resp.send({ success: false, status: 409, message: "RoomType already exists with same name" })
                else
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "RoomType updated Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No RoomType Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }


}


exports.delete = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!formData.status)
        validation += "status is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await RoomType.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.status)
                    res.status = formData.status
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "RoomType Status Changed Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No RoomType Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }


}

