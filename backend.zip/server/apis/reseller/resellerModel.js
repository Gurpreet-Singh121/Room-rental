const mongoose = require('mongoose')
const resellerSchema = mongoose.Schema({

    resellerId: { type: Number, default: 0 },
    
    name: { type: String, default: "" },
    image: { type: String, default: "reseller/default.jpg" },
    contact: { type:String, default: ""},
    address: { type:String, default: ""},
    aadharCardNo: { type:String, default: ""},

    email: { type:String, default: ""},
    password: { type:String, default: ""},

    status: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now }

})


const reseller = module.exports = mongoose.model('reseller', resellerSchema)
