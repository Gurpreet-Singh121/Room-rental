const Reseller = require('./resellerModel')
const helper = require('../../utilities/helpers')


exports.getAll = async (req, resp) => {
    await Reseller.find(req.body).then(res => {
        resp.send({ success: true, status: 200, message: "All Resellers loaded", data: res })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })
}



exports.getSingle = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })

    let query = { _id: formData._id }
    await Reseller.findOne(query).then(res => {
        if (!!res) {
            resp.send({ success: true, status: 200, message: "Reseller loaded Successfully", data: res })
        }
        else
            resp.send({ success: false, status: 404, message: "No Reseller Found" })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })

}



exports.addReseller = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData.name)
        validation += "name is required,"
    if (!formData.image)
        validation += "image is required,"
    if (!formData.contact)
        validation += "contact is required,"
    if (!formData.address)
        validation += "address is required,"
    if (!formData.aadharCardNo)
        validation += "aadharCardNo is required,"
    if (!formData.email)
        validation += "email is required,"
    if (!formData.password)
        validation += "password is required,"
    

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let total = await Reseller.countDocuments()
        let resellerData = {
            resellerId: total + 1,
            name: formData.name,
            image: "reseller/" + formData.image,
            contact: formData.contact,
            address: formData.address,
            aadharCardNo: formData.aadharCardNo,
            email: formData.email,
            password: formData.password
        }
        let reseller = new Reseller(resellerData)
        let prevReseller = await Reseller.findOne({ email: formData.email })
        if (prevReseller)
            resp.send({ success: false, status: 409, message: "Reseller already exists with same name" })
        else
            reseller.save().then(res => {
                resp.send({ success: true, status: 200, message: "Reseller added Successfully", data: res })

            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })
    }


}



exports.updateReseller = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Reseller.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.name)
                    res.name = formData.name
                if (!!formData.image)
                    res.image = "reseller/" + formData.image
                if (!!formData.contact)
                    res.contact = formData.contact
                if (!!formData.address)
                    res.address = formData.address
                if (!!formData.aadharCardNo)
                    res.aadharCardNo = formData.aadharCardNo
                if (!!formData.email)
                    res.email = formData.email
                if (!!formData.password)
                    res.password = formData.password
                let id = res._id
                let prevReseller = await Reseller.findOne({ $and: [{ email: res.email }, { _id: { $ne: id } }] })
                if (prevReseller)
                    resp.send({ success: false, status: 409, message: "Reseller already exists with same name" })
                else
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "Reseller updated Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No Reseller Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }


}

exports.delete = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!formData.status)
        validation += "status is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Reseller.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.status)
                    res.status = formData.status
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "Reseller Status Changed Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No Reseller Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }


}

