const Room = require('./roomModel')
const helper = require('../../utilities/helpers')


exports.getAll = async (req, resp) => {
    await Room.find(req.body).populate('resellerId').populate('cityId').populate('roomtypeId').then(res => {
        resp.send({ success: true, status: 200, message: "All Rooms loaded", data: res })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })
}



exports.getSingle = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })

    let query = { _id: formData._id }
    await Room.findOne(query).populate('resellerId').populate('cityId').populate('roomtypeId').then(res => {
        if (!!res) {
            resp.send({ success: true, status: 200, message: "Room loaded Successfully", data: res })
        }
        else
            resp.send({ success: false, status: 404, message: "No Room Found" })
    }).catch(err => {
        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
    })

}



exports.addRoom = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData.resellerId)
        validation += "resellerId is required,"
    if (!formData.roomtypeId)
        validation += "roomtypeId is required,"

    if (!formData.cityId)
        validation += "cityId is required,"
    if (!formData.address)
        validation += "address is required,"
    if (!formData.location)
        validation += "location is required,"
    if (!formData.description)
        validation += "description is required,"
    if (!formData.leasetime)
        validation += "leasetime is required,"
    if (!formData.price)
        validation += "price is required,"
    if (!formData.initialamount)
        validation += "initialamount is required,"

    if (!formData.image1)
        validation += "image1 is required,"
    if (!formData.image2)
        validation += "image2 is required,"


    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let total = await Room.countDocuments()
        let roomData = {
            roomId: total + 1,
            resellerId: formData.resellerId,
            roomtypeId: formData.roomtypeId,
            cityId: formData.cityId,
            address: formData.address,
            location: formData.location,
            description: formData.description,
            leasetime: formData.leasetime,
            price: formData.price,
            initialamount: formData.initialamount,
            image1: "room/" + formData.image1,
            image2: "room/" + formData.image2
        }
        let room = new Room(roomData)
        // let prevRoom = await Room.findOne({ name: formData.name })
        // if (prevRoom)
        //     resp.send({ success: false, status: 409, message: "Room already exists with same name" })
        // else
            room.save().then(res => {
                resp.send({ success: true, status: 200, message: "Room added Successfully", data: res })

            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })
    }


}


exports.updateRoom = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Room.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.resellerId)
                    res.resellerId = formData.resellerId
                if (!!formData.roomtypeId)
                    res.roomtypeId = formData.roomtypeId
                if (!!formData.cityId)
                    res.cityId = formData.cityId
                if (!!formData.address)
                    res.address = formData.address
                if (!!formData.location)
                    res.location = formData.location
                if (!!formData.leasetime)
                    res.leasetime = formData.leasetime
                if (!!formData.price)
                    res.price = formData.price
                if (!!formData.initialamount)
                    res.initialamount = formData.initialamount
                if (!!formData.image1)
                    res.image1 = "room/" + formData.image1
                if (!!formData.image2)
                    res.image2 = "room/" + formData.image2
                
                // let id = res._id
                // let prevRoom = await Room.findOne({ $and: [{ name: res.name }, { _id: { $ne: id } }] })
                // if (prevRoom)
                //     resp.send({ success: false, status: 409, message: "Room already exists with same name" })
                // else
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "Room updated Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No Room Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }


}


exports.delete = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"
    if (!formData.status)
        validation += "status is required"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Room.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.status)
                    res.status = formData.status
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "Room Status Changed Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No Room Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }
}