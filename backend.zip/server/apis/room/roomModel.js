const mongoose = require('mongoose')
const roomSchema = mongoose.Schema({

    roomId: { type: Number, default: 0 },

    resellerId: { type:mongoose.Schema.Types.ObjectId, default: null, ref:'reseller'},
    roomtypeId: { type:mongoose.Schema.Types.ObjectId, default: null, ref:'roomtype'},
    cityId: { type:mongoose.Schema.Types.ObjectId, default: null, ref:'city'},

    address: { type: String, default: "" },
    location: { type: String, default: "" },
    description: { type: String, default: "" },
    leasetime: { type: String, default: "" },
    price: { type: Number, default: 0 },
    initialamount: { type: Number, default: 0 },

    image1: { type: String, default: "room/default.jpg" },
    image2: { type: String, default: "room/default.jpg" },

    status: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now }

})


const room = module.exports = mongoose.model('room', roomSchema)
