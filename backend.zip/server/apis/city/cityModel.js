const mongoose = require('mongoose')
const citySchema = mongoose.Schema({

    cityId: { type: Number, default: 0 },
    name: { type: String, default: "" },
    thumbnail: { type: String, default: "city/default.jpg" },
    status: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now }

})


const city = module.exports = mongoose.model('city', citySchema)
