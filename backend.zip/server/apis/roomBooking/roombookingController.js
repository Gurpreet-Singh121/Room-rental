const Roombooking = require('./roombookingModel')
const helper = require('../../utilities/helpers')


exports.getAll = async (req, resp) => {
    await Roombooking.find(req.body)
        .populate("roomId")
        .then(res => {
            resp.send({ success: true, status: 200, message: "All Room Bookings loaded", data: res })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
}


exports.getSingle = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })

    let query = { _id: formData._id }
    await Roombooking.findOne(query)
        .populate("roomId")
        .then(res => {
            if (!!res) {
                resp.send({ success: true, status: 200, message: "Room Booking loaded Successfully", data: res })
            }
            else
                resp.send({ success: false, status: 404, message: "No Room Booking Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })

}




exports.addRoombooking = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData.roomId)
        validation += "roomId is required,"
    if (!formData.userId)
        validation += "userId is required,"
    if (!formData.name)
        validation += "name is required,"
    if (!formData.people)
        validation += "people is required,"
    if (!formData.date)
        validation += "date is required,"
    if (!formData.message)
        validation += "message is required,"
    if (!formData.transactionId)
        validation += "transactionId is required,"
    if (!formData.cvv)
        validation += "cvv is required,"
    if (!formData.cardNo)
        validation += "cardNo is required,"
    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let total = await Roombooking.countDocuments()
        let roombookingData = {
            roombookingId: total + 1,
            roomId: formData.roomId,
            userId: formData.userId,
            name: formData.name,
            people: formData.people,
            date: formData.date,
            message: formData.message,
            transactionId: formData.transactionId,
            cvv: formData.cvv,
            cardNo: formData.name
        }
        let roombooking = new Roombooking(roombookingData)
            roombooking.save().then(res => {
                resp.send({ success: true, status: 200, message: "Roombooking added Successfully", data: res })

            }).catch(err => {
                resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
            })
    }


}



exports.updateRoombookingStatus = async (req, resp) => {
    let formData = req.body
    let validation = ""
    if (!formData._id)
        validation += "_id is required"

    if (!!validation)
        resp.send({ success: false, status: 422, message: validation })
    else {
        let query = { _id: formData._id }
        await Roombooking.findOne(query).then(async res => {
            if (!!res) {
                if (!!formData.bookingStatus)
                    res.bookingStatus = formData.bookingStatus
                    res.save().then(res => {
                        resp.send({ success: true, status: 200, message: "Roombooking status updated Successfully", data: res })

                    }).catch(err => {
                        resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
                    })
            }
            else
                resp.send({ success: false, status: 404, message: "No Roombooking Found" })
        }).catch(err => {
            resp.send({ success: false, status: 500, message: !!err.message ? err.message : err })
        })
    }

}

