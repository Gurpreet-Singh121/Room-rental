const mongoose = require('mongoose')
const roombookingSchema = mongoose.Schema({
    roombookingId: { type: Number, default: 0 },
    roomId: { type: mongoose.Schema.Types.ObjectId, default: null, ref: 'room' },
    userId: { type: mongoose.Schema.Types.ObjectId, default: null, ref: 'user' },
    name: { type: String, default: "" },
    people: { type: Number, default: 0 },
    date: { type: Date, default: Date.now },
    message: { type: String, default: "" },
    transactionId: { type:String, default:''},
    cvv: { type:String, default:''},
    cardNo: { type:String, default:''},
    bookingStatus: { type: String, default: 'pending' }, //approved and declined
    createdAt: { type: Date, default: Date.now }

})


const roombooking = module.exports = mongoose.model('roombooking', roombookingSchema)
