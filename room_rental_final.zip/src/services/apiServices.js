import axios from "axios";
import * as qs from "qs";
const BASE_URL="http://localhost:3004/api/"
export const BASE_URL_Image="http://localhost:3004/"
const token=sessionStorage.getItem("token")
// console.log(token)
let header={
    "Accept":"*/*",
    "Authorization":sessionStorage.getItem("token")
}
class apiServices{
    login(data) {
        return axios.post(BASE_URL+"user/login",data)
    }
    getDashboard(data){
        // console.log(token)
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.get(BASE_URL+"dashboard",{headers:header})
    }
    addCity(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"city/add",data,{headers:header})
    }
    getAllCity(data){
        return axios.post(BASE_URL+"city/all",data)
    }
    getSingleCity(data){
        return axios.post(BASE_URL+"city/single",data)
    }
    updateCity(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"city/update",data,{headers:header})
    }
    changeStatusCity(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"city/delete",qs.stringify(data),{headers:header})
    }
    addReseller(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"reseller/add",data,{headers:header})
    }
    getAllReseller(data){
        return axios.post(BASE_URL+"reseller/all",data)
    }
    getSingleReseller(data){
        return axios.post(BASE_URL+"reseller/single",data)
    }
    updateReseller(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"reseller/update",data,{headers:header})
    }
    changeStatusReseller(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"reseller/delete",qs.stringify(data),{headers:header})
    }
    addRoomType(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roomtype/add",data,{headers:header})
    }
    getAllRoomType(data){
        return axios.post(BASE_URL+"roomtype/all",data)
    }
    getSingleRoomType(data){
        return axios.post(BASE_URL+"roomtype/single",data)
    }
    updateRoomType(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roomtype/update",data,{headers:header})
    }
    changeStatusRoomType(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roomtype/delete",qs.stringify(data),{headers:header})
    }
    addRoom(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"room/add",data,{headers:header})
    }
    getAllRoom(data){
        return axios.post(BASE_URL+"room/all",data)
    }
    getSingleRoom(data){
        return axios.post(BASE_URL+"room/single",data)
    }
    updateRoom(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"room/update",data,{headers:header})
    }
    changeStatusRoom(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"room/delete",qs.stringify(data),{headers:header})
    }
    addUser(data){
        return axios.post(BASE_URL+"user/add",data)
    }
    bookRoom(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roombooking/add",data,{headers:header})
    }
    userBooking(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roombooking/all",data,{headers:header})
    }
    updateBooking(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"roombooking/updateStatus",data,{headers:header})
    }
    addContact(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"enquiry/add", data,{headers:header})
    }
    viewContact(data){
        let header={
            "Accept":"*/*",
            "Authorization":sessionStorage.getItem("token")
        }
        return axios.post(BASE_URL+"enquiry/all", data,{headers:header})
    }
}
export default new apiServices