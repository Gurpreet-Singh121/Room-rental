import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Main from './components/Main';
import Contact from './components/Contact';
import Register from './authentication/Register';
import Login from './authentication/Login';
import Master from './layouts/Master';
import Dashboard from './components/admin/Dashboard';
import AddCity from './components/admin/cities/AddCity.js';
import ManageCity from './components/admin/cities/ManageCity';
import UpdateCity from './components/admin/cities/UpdateCity';
import AddReseller from './components/admin/resellers/AddReseller';
import ManageReseller from './components/admin/resellers/ManageReseller';
import UpdateReseller from './components/admin/resellers/UpdateReseller';
import AddRoom from './components/admin/rooms/AddRoom';
import ManageRoom from './components/admin/rooms/ManageRoom';
import UpdateRoom from './components/admin/rooms/UpdateRoom';
import AddRoomType from './components/admin/roomtypes/AddRoomType';
import ManageRoomType from './components/admin/roomtypes/ManageRoomType';
import UpdateRoomType from './components/admin/roomtypes/UpdateRoomType';
import ViewRoom from './components/admin/rooms/ViewRoom';
import ViewType from './components/users/views/ViewType';
import ViewCity from './components/users/views/ViewCity';
import UserRoom from './components/users/views/UserRoom';
import SingleRoom from './components/users/views/SingleRoom';
import UserRoomType from './components/users/views/UserRoomType';
import Book_Room from './components/users/bookings/Book_Room';
import ViewBooking from './components/users/bookings/ViewBooking';
import Booking from './components/admin/bookings/Booking';
import UserMaster from './layouts/UserMaster';
import ViewContact from './components/admin/ViewContact';
function App() {
  return (
    <>
    <Router>
      <Routes>
        <Route path="/admin" element={<Master/>}>
          <Route path="/admin" element={<Dashboard/>}/>
          <Route path="/admin/add_city" element={<AddCity/>}/>
          <Route path="/admin/manage_city" element={<ManageCity/>}/>
          <Route path="/admin/update_city/:id" element={<UpdateCity/>}/>
          <Route path="/admin/add_reseller" element={<AddReseller/>}/>
          <Route path="/admin/manage_reseller" element={<ManageReseller/>}/>
          <Route path="/admin/update_reseller/:id" element={<UpdateReseller/>}/>
          <Route path="/admin/add_room_type" element={<AddRoomType/>}/>
          <Route path="/admin/manage_room_type" element={<ManageRoomType/>}/>
          <Route path="/admin/update_room_type/:id" element={<UpdateRoomType/>}/>
          <Route path="/admin/add_room" element={<AddRoom/>}/>
          <Route path="/admin/manage_room" element={<ManageRoom/>}/>
          <Route path="/admin/update_room/:id" element={<UpdateRoom/>}/>
          <Route path="/admin/view_room/:id" element={<ViewRoom/>}/>
          <Route path="/admin/admin_booking" element={<Booking/>}/>
          <Route path="/admin/view_enquiry" element={<ViewContact/>}/>
        </Route>
        <Route path="/" element={<UserMaster/>}>
          <Route path="/" element={<Main/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/register" element={<Register/>}/>
          <Route path="/user/view_type" element={<ViewType/>}/>
          <Route path="/user/view_city" element={<ViewCity/>}/>
          <Route path="/user/view_room" element={<UserRoom/>}/>
          <Route path="/user/view_room/:id" element={<UserRoom/>}/>
          <Route path="/user/view_room_type/:id" element={<UserRoomType/>}/>
          <Route path="/user/single_room/:id" element={<SingleRoom/>}/>
          <Route path="/book_room/:id" element={<Book_Room/>}/>
          <Route path="/booking" element={<ViewBooking/>}/>
        </Route>
      </Routes>
    </Router>
    </>
  );
}

export default App;
