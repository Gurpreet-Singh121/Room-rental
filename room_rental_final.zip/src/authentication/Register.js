import { useState } from "react"
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import apiServices from "../services/apiServices";
import { useNavigate } from "react-router-dom";
export default function Register(){
    const [name,setName]=useState()
    const [email,setEmail]=useState()
    const [password,setPassword]=useState()
    const [contact,setContact]=useState()
    const [profile,setProfile]=useState()
    const [gender,setGender]=useState()
    const [loading,setLoading]=useState(false)
    const changeGender=(e)=>{
        setGender(e.target.value)
    }
    const navigate=useNavigate()
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    const handleForm=(e)=>{
        e.preventDefault()
        setLoading(true)
        let data={
            name:name,
            email:email,
            password:password,
            contact:contact,
            gender:gender,
            image:profile
        }
        apiServices.addUser(data).then((data)=>{
            console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
                setContact("")
                setEmail("")
                // setGender()
                setName("")
                setPassword("")
                setProfile("")
                setTimeout(()=>{
                    navigate("/login")
                },1000)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    function checkContact(){
        var contact=document.getElementById('contact').value 
        var pattern_contact=/^[6-9]{1}[0-9]{9}$/
        if(pattern_contact.test(contact)){
            document.getElementById('error_contact').innerHTML=""
        }
        else{
            document.getElementById('contact').value=""
            document.getElementById('error_contact').innerHTML="Please Enter Valid Contact"
        }
    }
    function checkEmail(){
        var email=document.getElementById('email').value
        // console.log(email)
        var pattern_email=/^[a-zA-Z0-9/./-/_]+\@+[a-zA-Z0-9]+\.+[a-zA-Z]{2,3}$/
        if(pattern_email.test(email)){
            console.log('valid')
            document.getElementById('error_email').innerHTML=""
        }
        else{
            console.log('invalid')
            document.getElementById('email').value=""
            document.getElementById('error_email').innerHTML="Please Enter Valid email"
        }
    }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Register</h1>
                        <form>
                        <div className="row">
                            <div className="col-md-2 offset-md-1">
                                <label>Name</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="text" required value={name} onChange={(e)=>{setName(e.target.value)}}/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Contact</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" required type="number" value={contact} onChange={(e)=>{setContact(e.target.value)}} id="contact" onBlur={checkContact}/>
                                <span id="error_contact" class="text-danger"></span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-2 offset-md-1">
                                <label>Email</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" required type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} id="email" onBlur={checkEmail}/>
                                <span id="error_email" class="text-danger"></span>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Password</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" required type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}}/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Gender</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-check-input" type="radio"  value={'Male'} name="gender" required onChange={changeGender}/><span className="px-2">Male</span>
                                <input className="form-check-input" required type="radio"  name="gender" onChange={changeGender} value={'Female'} /><span className="px-2" >Female</span>
                                <input className="form-check-input" required type="radio"  value={'Other'} name="gender" onChange={changeGender}/><span className="ps-2">Other</span>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-2 offset-md-1">
                                <label>Profile Picture</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" required type="file" onChange={(e)=>{setProfile(e.target.files[0])}}/>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center my-3">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Register</button>
                        </div>
                        </form>
                    </div>
                </section>
            </main>
        </div>
        </>
    )
}