import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import apiServices from '../services/apiServices';
import { toast } from 'react-toastify';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ClipLoader } from 'react-spinners';
export default function Login(){
    const navigate=useNavigate()
    const [loading,setLoading]=useState(false)
    const[message,setMessage]=useState()
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
        
    }
    useEffect(()=>{
        setMessage(sessionStorage.getItem("message"))
        if(message){
            toast.error(message)
            setTimeout(()=>{
                sessionStorage.removeItem("message")
            },2000)
        }
    },[message])
    const [email, setEmail]=useState()
    const [password, setPassword]=useState()
    const handleForm=(e)=>{
        e.preventDefault();
        setLoading(true)
        let data={
            email:email,
            password:password
        }
        apiServices.login(data).then((data)=>{
            setLoading(false)
            if(data.data.success){
                toast.success(data.data.message)
                // console.warn(data.data.token)
                sessionStorage.setItem("user_id", data.data.data._id)
                sessionStorage.setItem("user_name", data.data.data.name)
                sessionStorage.setItem("user_email", data.data.data.email)
                sessionStorage.setItem("token", data.data.token)
                sessionStorage.setItem("user_type", data.data.data.userType)
                sessionStorage.setItem("authenticate",true)
                if(data.data.data.userType==1|| data.data.data.userType=="1"){
                    navigate("/admin")
                }
                else{
                    navigate("/")
                }
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            console.log(error)
            toast.error("Something went Wrong")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section class="intro-single">
                    <div class="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Login</h1>
                        <form onSubmit={handleForm}>
                            <div className="row my-3">
                                <div className="col-md-2">
                                    <label>Email</label>
                                </div>
                                <div className="col-md-10">
                                    <input className="form-control" type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}}/>
                                </div>
                            </div>
                            <div className='row'>
                                <div className="col-md-2">
                                    <label>Password</label>
                                </div>
                                <div className="col-md-10">
                                    <input className="form-control" type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}}/>
                                </div>
                            </div>
                            <div className="row my-3">
                                <div className='col-md-5 offset-md-4'>
                                    <button className='form-control btn btn-success'>Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
            </main>
        </div>
            <ToastContainer
            position="top-right"
            autoClose={3000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme="light"
            />
        </>
    )
}