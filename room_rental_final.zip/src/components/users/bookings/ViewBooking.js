import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function ViewBooking(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const [booking,setBooking]=useState()
    useEffect(()=>{
        const userId=sessionStorage.getItem("user_id")
        let data={
            userId:userId
        }
        apiServices.userBooking(data).then((data)=>{
            console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setBooking(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[])
    const authenticate=sessionStorage.getItem("authenticate")
    const userType=sessionStorage.getItem("user_type")
    if(!authenticate){
        sessionStorage.setItem("message", "Please Login!!")
        return <Navigate replace to="/login"/>
    }
    if(userType !=2){
        sessionStorage.setItem("message", "You don't have the right to access this page!!")
        return <Navigate replace to="/login"/>
    }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Rooms</h1>
                    <div className="container my-5 table-responsive">
                        <table className="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Image</th>
                                    {/* <th>Reseller</th>
                                    <th>City</th> */}
                                    {/* <th>Type</th> */}
                                    <th>Price</th>
                                    <th>Initial Amount</th>
                                    <th>Lease Time</th>
                                    <th>Location</th>
                                    {/* <th>Description</th> */}
                                    <th>Address</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    {/* <th>View</th>
                                    <th>Edit</th>
                                    <th>Delete</th> */}
                                </tr>
                            </thead>
                            {booking?.map((element,index)=>(
                                <tr key={index+1}>
                                    <td>{index+1}</td>
                                    <td>
                                        <img src={BASE_URL_Image+element?.roomId?.image1} className="img-fluid w-100" style={{height:"150px"}}/>
                                    </td>
                                    {/* <td>{element?.resellerId?.name}</td>
                                    <td>{element?.cityId?.name}</td> */}
                                    {/* <td>{element?.roomtypeId?.name}</td> */}
                                    <td>&#8377; {element?.roomId?.price}</td>
                                    <td>&#8377; {element?.roomId?.initialamount}</td>
                                    <td>{element?.roomId?.leasetime} yrs</td>
                                    <td>{element?.roomId?.location}</td>
                                    {/* <td>{element?.description}</td> */}
                                    <td>{element?.roomId?.address}</td>
                                    <td>{element?.date}</td>
                                    <td>{element?.bookingStatus}</td>
                                    {/* <td>
                                        <Link to={`/view_room/${element?._id}`}>
                                            <i className="bi bi-eye fs-3 text-info"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <Link to={`/update_room/${element?._id}`}>
                                            <i className="bi bi-pencil-square fs-3 text-success"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <i className="bi bi-trash text-danger fs-3" onClick={()=>{
                                            deleteData(element?._id)
                                        }}></i>
                                    </td> */}
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}