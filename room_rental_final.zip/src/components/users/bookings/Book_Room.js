import { useState } from "react"
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import { useEffect } from "react"
import { Navigate, useNavigate, useParams } from "react-router-dom";
export default function Book_Room(){
    const [loading,setLoading]=useState(false)
    const [room,setRoom]=useState()
    const [message,setMessage]=useState()
    const user_name=sessionStorage.getItem("user_name")
    const [user,setName]=useState(user_name)
    const [people,setPeople]=useState(1)
    const [date,setDate]=useState()
    const [card,setCard]=useState()
    const [cvv,setCVV]=useState()
    const [roomId,setroomId]=useState()
    const navigate=useNavigate()
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    const param=useParams()
    const id=param.id
    useEffect(()=>{
        setLoading(true)
        let data_id={
            _id:id,
        }
        apiServices.getSingleRoom(data_id).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setRoom(data.data.data)
                setroomId(data.data.data._id)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((data)=>{
             // console.log(error)
             toast.error("Something went wrong!!Try Again Later")
             setTimeout(()=>{
                setLoading(false)
             },1500)
        })
    },[])
    const handleForm=(e)=>{
        e.preventDefault();
        window.alert("Do you really want to Proceed?")
        setLoading(true)
        let trans=Math.round(Math.random()*100000)
        let userId=sessionStorage.getItem("user_id")
        let data={
           name:user,
           people:people,
           date:date,
           message:message,
           transactionId:trans,
           cvv:cvv,
           cardNo:card,
           roomId:roomId,
           userId:userId,
        }
        apiServices.bookRoom(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                // console.log(data)
                toast.success(data.data.message)
                let data_id={
                    _id:id,
                    status:false,
                }
                apiServices.deleteRoom(data_id).then((x)=>{
                    setTimeout(()=>{
                        navigate("/booking")
                    },2000)
                }).catch((error)=>{
                    console.log(error)
                })
                
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    const authenticate=sessionStorage.getItem("authenticate")
    const userType=sessionStorage.getItem("user_type")
    if(!authenticate){
        sessionStorage.setItem("message", "Please Login!!")
        return <Navigate replace to="/login"/>
    }
    if(userType !=2){
        sessionStorage.setItem("message", "You don't have the right to access this page!!")
        return <Navigate replace to="/login"/>
    }
   const checkCvv=()=>{
        var cvv=document.getElementById('cvv').value 
        var pattern_cvv=/^[0-9]{3,4}$/
        if(pattern_cvv.test(cvv)){
            document.getElementById('error_cvv').innerHTML=""
        }
        else{
            document.getElementById('cvv').value=""
            document.getElementById('error_cvv').innerHTML="Please Enter Valid cvv of three or four digits"
        }
    }
    const checkCard=()=>{
        var card=document.getElementById('card').value 
        var pattern_card=/^[0-9]{16}$/
        if(pattern_card.test(card)){
            document.getElementById('error_card').innerHTML=""
        }
        else{
            document.getElementById('card').value=""
            document.getElementById('error_card').innerHTML="Please Enter Valid card number of 16 digits"
        }
    }
    return(
        <>
        <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>    
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Booking</h1>
                        <div className="row my-3">
                            <div className="col-md-6 offset-md-3">
                                <div className="card">
                                    <div className="row">
                                    <div className="col-md-4">
                                        <img src={BASE_URL_Image+room?.image1} className="card-img-top" style={{height:"200px"}}/>
                                    </div>
                                    <div className="col-md-8">
                                        <h4>{room?.roomtypeId?.name}</h4>
                                        <h4>Location: {room?.location}, {room?.address}</h4>
                                        <h4>Total Price: {room?.price}</h4>
                                        <h3>Initial Amount: &#8377;{room?.initialamount}</h3>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form>
                        <div className="row">
                            <div className="col-md offset-md-1 ">
                                <label>Name</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" value={user} onChange={(e)=>{setName(e.target.value)}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>People</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={people} onChange={(e)=>{setPeople(e.target.value)}} required/>
                            </div>
                        </div>
                        <div className="row my-3">  
                            <div className="col-md offset-md-1 ">
                                <label>Date</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="date" value={date} onChange={(e)=>{setDate(e.target.value)}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Card Number</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={card} onChange={(e)=>{setCard(e.target.value)}} onBlur={checkCard} id="card" required />
                                <span id="error_card" class="text-danger"></span>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md offset-md-1">
                                <label>CVV</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="password" value={cvv} onChange={(e)=>{setCVV(e.target.value)}} required onBlur={checkCvv} id="cvv"  />
                                <span id="error_cvv" class="text-danger"></span>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Message</label>
                            </div>
                            <div className="col-md-4">
                                <textarea className="form-control" rows="1" onChange={(e)=>{setMessage(e.target.value)}} value={message} required >{message}</textarea>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Update</button>
                        </div>
                        </form>
                    </div>
                </section>
            </main>
        </div>
        </>
    )
}