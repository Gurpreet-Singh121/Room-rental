import { useEffect, useState } from "react"
import apiServices, { BASE_URL_Image } from "../../../services/apiServices"
import { useParams } from "react-router-dom"
import { toast } from "react-toastify";
import { ClipLoader } from "react-spinners";
import { Link } from "react-router-dom";
export default function SingleRoom(){
    const [room,setRoom]=useState()
    const [loading,setLoading]=useState(false)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const param=useParams()
    const id=param.id
    useEffect(()=>{
        let data={
            _id:id
        }
        apiServices.getSingleRoom(data).then((data)=>{
            // console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setRoom(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[])
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Rooms</h1>
                        <div className="container ">
                            <div className="card text-capitalize p-5 mb-4">
                                <div className="row">
                                    <div className="col-md-5">
                                    <div id="carouselExampleIndicators" class="carousel slide">
                                        <div class="carousel-indicators">
                                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                        </div>
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                            <img src={BASE_URL_Image+room?.image1} class="d-block w-100" alt="..." style={{maxHeight:"500px"}}/>
                                            </div>
                                            <div class="carousel-item">
                                            <img src={BASE_URL_Image+room?.image2} class="d-block w-100" alt="..." style={{maxHeight:"500px"}}/>
                                            </div>
                                        </div>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Previous</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden">Next</span>
                                        </button>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <h1 className="card-text">{room?.roomtypeId?.name}</h1>
                                        <p>{room?.description}</p>
                                        <h4 className="card-text">Reseller : {room?.resellerId?.name}</h4>
                                        <h4 className="card-text">City : {room?.cityId?.name}</h4>
                                        <h5 className="card-text">Address : {room?.address+", "+ room?.cityId?.name}</h5>
                                        <h5 className="card-text">Location: {room?.location}</h5>
                                        <h5 className="card-text">Price: &#8377; {room?.price}</h5>
                                        <h5 className="card-text">Lease Time: {room?.leasetime}</h5>
                                        <h5 className="card-text">Initial Amount: &#8377; {room?.initialamount}</h5>
                                        <div className="d-flex justify-content-center">
                                            <Link to={`/book_room/${room?._id}`}>
                                            <button className="btn btn-outline-success">
                                                Book
                                            </button>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </div>
        </>
    )
}