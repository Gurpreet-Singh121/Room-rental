import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function ViewType(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"45%",
        "zIndex":"1",
    }
    const [name,setName]=useState()
    useEffect(()=>{
        apiServices.getAllRoomType().then((data)=>{
            // console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setName(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[])
    return(
        <>
            <div className="d-flex justify-content-center">
                <ClipLoader loading={loading} cssOverride={override} size={120}/>
            </div>
        <div className={loading?"disabled-screen-full":""}> 
        <main id="main">
            <section className="intro-single px-5">
                <div className="container-fluid border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Types</h1>
                    <div className="row">
                        {name?.map((el,index)=>(
                                <div className="col-md-4 my-3 p-3" key={index}>
                                <Link to={`/user/view_room_type/${el?._id}`}>
                                <div className="card p-4">
                                    <h2 className="card-text">
                                    {el?.name} <i className="bi bi-chevron-right"></i>
                                    </h2>
                                </div>
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}