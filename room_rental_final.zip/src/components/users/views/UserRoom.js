import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import apiServices, { BASE_URL_Image } from "../../../services/apiServices"
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { ClipLoader } from "react-spinners"
export default function UserRoom(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%",
        "zIndex":"1",
    }
    const [room,setRoom]=useState()
    const param=useParams()
    const id=param.id
    useEffect(()=>{
        if(id!=null){
            var data={
                cityId:id,
                status:true
            }
        }
        else{
            var data={
                status:true
            }
        }
        apiServices.getAllRoom(data).then((data)=>{
            console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setRoom(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[])
    
    
    return(
        <>
          <div className="d-flex justify-content-center">
                <ClipLoader loading={loading} cssOverride={override} size={120}/>
            </div>
        <div className={loading?"disabled-screen-full":""}> 
        <main id="main">
            <section className="intro-single px-5">
                <div className="container-fluid border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Property</h1>
                    <div className="row">
                        {room?.map((el,index)=>(
                                <div className="col-md-4 my-3 p-3" key={index}>
                                <Link to={`/user/view_room/${el?._id}`}>
                                <div className="card text-center p-4" style={{maxHeight:"600px"}}>
                                    <img src={BASE_URL_Image+`${el?.image1}`} className="card-img-top" style={{height:"260px"}}/>
                                    <h3 className="card-text">
                                    {el?.roomtypeId?.name}
                                    <br/>
                                    {el?.location},
                                    {el?.address} 
                                    </h3>
                                    <h3>Price- &#8377; {el?.price}</h3>
                                    <h4 className="card-text">Booking Amount- &#8377; {el?.initialamount}</h4>
                                    <p className="card-text">Lease Time- {el?.leasetime} years</p>
                                    <Link to={"/user/single_room/"+`${el?._id}`}>
                                    <button className="btn btn-outline-success">View More</button>
                                    </Link>
                                    {/* <p className="card-text" style={{overflow:"hidden",height:"100px"}}>{el?.description}</p> */}
                                </div>
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}