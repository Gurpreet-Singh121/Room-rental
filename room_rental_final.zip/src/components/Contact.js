import { useState } from "react"
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import apiServices from "../services/apiServices";
import { Navigate } from "react-router-dom";
export default function Contact(){
    const [name, setName]=useState()
    const [email, setEmail]=useState()
    const [contact, setContact]=useState()
    const [subject, setSubject]=useState()
    const [message, setMessage]=useState()
    const [loading,setLoading]=useState(false)
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"45%",
        "zIndex":"1",
    }
    const handleForm=(e)=>{
        e.preventDefault()
        setLoading(true)
        let data={
            name: name,
            email: email,
            contact: contact,
            subject: subject,
            message:message
        }
        apiServices.addContact(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
                setContact("")
                setEmail("")
                setMessage("")
                setName("")
                setSubject("")
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    const authenticate=sessionStorage.getItem("authenticate")
    const userType=sessionStorage.getItem("user_type")
    if(!authenticate){
        sessionStorage.setItem("message", "Please Login!!")
        return <Navigate replace to="/login"/>
    }
    if(userType !=2){
        sessionStorage.setItem("message", "You don't have the right to access this page!!")
        return <Navigate replace to="/login"/>
    }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}> 
            <main id="main">

                {/* <!-- ======= Intro Single ======= --> */}
                <section className="intro-single">
                <div className="container">
                    <div className="row">
                    <div className="col-md-12 col-lg-8">
                        <div className="title-single-box">
                        <h1 className="title-single">Contact US</h1>
                        <span className="color-text-a">Home Rental is a website to rent Houses, Flats, Rooms and building at your nearby location easily, We provide Help in Finding the place of your dreams at the best price. You can contact us for any enquiry by filling the form given</span>
                        </div>
                    </div>
                    <div className="col-md-12 col-lg-4">
                        <nav aria-label="breadcrumb" className="breadcrumb-box d-flex justify-content-lg-end">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                            <a >Home</a>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">
                            Contact
                            </li>
                        </ol>
                        </nav>
                    </div>
                    </div>
                </div>
                </section>
                {/* <!-- End Intro Single--> */}

                {/* <!-- ======= Contact Single ======= --> */}
                <section className="contact">
                <div className="container">
                    <div className="row">
                    <div className="col-sm-12 section-t8">
                        <div className="row">
                        <div className="col-md-7">
                            <form onSubmit={handleForm} method="post" role="form" className="php-email-form">
                            <div className="row">
                                <div className="col-md-6 mb-3">
                                <div className="form-group">
                                    <input type="text" name="name" className="form-control form-control-lg form-control-a" placeholder="Your Name" required value={name} onChange={(e)=>{setName(e.target.value)}}/>
                                </div>
                                </div>
                                <div className="col-md-6 mb-3">
                                <div className="form-group">
                                    <input name="contact" type="number" className="form-control form-control-lg form-control-a" placeholder="Your Contact" required value={contact} onChange={(e)=>{setContact(e.target.value)}}/>
                                </div>
                                </div>
                                <div className="col-md-12 mb-3">
                                <div className="form-group">
                                    <input name="email" type="email" className="form-control form-control-lg form-control-a" placeholder="Your Email" required value={email} onChange={(e)=>{setEmail(e.target.value)}}/>
                                </div>
                                </div>
                                <div className="col-md-12 mb-3">
                                <div className="form-group">
                                    <input type="text" name="subject" className="form-control form-control-lg form-control-a" placeholder="Subject" required value={subject} onChange={(e)=>{setSubject(e.target.value)}}/>
                                </div>
                                </div>
                                <div className="col-md-12">
                                <div className="form-group">
                                    <textarea name="message" className="form-control"  cols="45" rows="8" placeholder="Message" required value={message} onChange={(e)=>{setMessage(e.target.value)}}>{message}</textarea>
                                </div>
                                </div>
                                <div className="col-md-12 my-3">
                                <div className="mb-3">
                                    <div className="loading">Loading</div>
                                    <div className="error-message"></div>
                                    <div className="sent-message">Your message has been sent. Thank you!</div>
                                </div>
                                </div>

                                <div className="col-md-12 text-center">
                                <button type="submit" className="btn btn-a">Send Message</button>
                                </div>
                            </div>
                            </form>
                        </div>
                        <div className="col-md-5 section-md-t3">
                            <div className="icon-box section-b2">
                            <div className="icon-box-icon">
                                <span className="bi bi-envelope"></span>
                            </div>
                            <div className="icon-box-content table-cell">
                                <div className="icon-box-title">
                                <h4 className="icon-title">Say Hello</h4>
                                </div>
                                <div className="icon-box-content">
                                <p className="mb-1">Email.
                                    <span className="color-a">contact@home_rental.com</span>
                                </p>
                                <p className="mb-1">Phone.
                                    <span className="color-a">+91-9894394792</span>
                                </p>
                                </div>
                            </div>
                            </div>
                            <div className="icon-box section-b2">
                            <div className="icon-box-icon">
                                <span className="bi bi-geo-alt"></span>
                            </div>
                            <div className="icon-box-content table-cell">
                                <div className="icon-box-title">
                                <h4 className="icon-title">Find us in</h4>
                                </div>
                                <div className="icon-box-content">
                                <p className="mb-1">
                                    Jalandhar, Punjab
                                    <br/> India
                                </p>
                                </div>
                            </div>
                            </div>
                            <div className="icon-box">
                            <div className="icon-box-icon">
                                <span className="bi bi-share"></span>
                            </div>
                            <div className="icon-box-content table-cell">
                                <div className="icon-box-title">
                                <h4 className="icon-title">Social networks</h4>
                                </div>
                                <div className="icon-box-content">
                                <div className="socials-footer">
                                    <ul className="list-inline">
                                    <li className="list-inline-item">
                                        <a href="#" className="link-one">
                                        <i className="bi bi-facebook" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="#" className="link-one">
                                        <i className="bi bi-twitter" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="#" className="link-one">
                                        <i className="bi bi-instagram" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="#" className="link-one">
                                        <i className="bi bi-linkedin" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    </ul>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </section>
                {/* <!-- End Contact Single--> */}

            </main>
            {/* <!-- End #main --> */}
            </div>
        </>
    )
}