import { ClipLoader } from "react-spinners"
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import apiServices from "../../services/apiServices";
import { toast } from "react-toastify";
export default function Dashboard(){
    const [loading,setLoading]=useState(true)
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    const [totalData,setTotalData]=useState()
   
    useEffect(()=>{
        apiServices.getDashboard().then((data)=>{
            setLoading(false)
           setTotalData(
                {
                    "totalRoomtypes": data.data.totalRoomtypes,
                    "totalResellers": data.data.totalResellers,
                    "totalRooms": data.data.totalRooms,
                    "totalRoombookings": data.data.totalRoombookings,
                    "totalEnquiries": data.data.totalEnquiries,
                    "totalBuyers": data.data.totalBuyers,
                    "totalCities": data.data.totalCities
                }
           )
            // console.log(totalData)
        }).catch((error)=>{
            console.log(error)
            toast.error("Something went Wrong!!")
            setTimeout(()=>{
                setLoading(false)
            },2000)
        })
    },[])
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container ">
                    <h1 className="text-center">Welcome Admin</h1>
                </div>
                <div className="container my-5 ">
                <div className="row text-center">
                    <div className="col-md-4 my-3  ">
                        <div className="card text-center">
                            <i className="bi bi-person text-danger fs-1"></i>
                            <h1 className="card-title">Buyers</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalBuyers}</h1>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-3">
                        <div className="card  text-center">
                            <i className="bi bi-airplane fs-1 text-info"></i>
                            <h1 className="card-title">Cities</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalCities}</h1>
                            </div>
                        </div>
                        
                    </div>
                    <div className="col-md-4 my-3">
                        <div className="card  text-center">
                            <i className="bi bi-building fs-1 text-success"></i>
                            <h1 className="card-title">Rooms</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalRooms}</h1>
                            </div>
                        </div>
                        
                    </div>
                    <div className="col-md-4 my-3  ">
                        <div className="card text-center">
                            <i className="bi bi-ticket fs-1 text-primary"></i>
                            <h1 className="card-title">Bookings</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalRoombookings}</h1>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-3">
                        <div className="card  text-center">
                            <i className="bi bi-patch-question fs-1 text-success"></i>
                            <h1 className="card-title">Enquiry</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalEnquiries}</h1>
                            </div>
                        </div>
                        
                    </div>
                    <div className="col-md-4 my-3">
                        <div className="card  text-center">
                        <i className="bi bi-person-fill fs-1 text-warning"></i>
                            <h1 className="card-title">Resellers</h1>
                            <div className="card-body text-center">
                                <h1>{totalData?.totalResellers}</h1>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            </section>
        </main>
        </div>
        </>
    )
}