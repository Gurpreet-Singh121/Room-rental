import { useState } from "react"
import apiServices from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
export default function AddCity(){
    const [city,setCity]=useState()
    const [image,setImage]=useState()
    const [loading,setLoading]=useState(false)
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    const handleForm=(e)=>{
        e.preventDefault()
        setLoading(true)
        let data=new FormData()
        data.append("name", city)
        data.append("city_image", image)
        apiServices.addCity(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
                setCity("")
                setImage("")
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    return(
        <>
          <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Add City</h1>
                        <form>
                        <div className="row">
                            <div className="col-md-2 offset-md-1">
                                <label>City Name</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="text" value={city} onChange={(e)=>{setCity(e.target.value)}} required/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Thumbnail</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="file"  onChange={(e)=>{setImage(e.target.files[0])}} required/>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Submit</button>
                        </div>
                        </form>
                    </div>
                </section>
            </main>
            </div>
        </>
    )
}