import { useEffect, useState } from "react"
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import { useNavigate, useParams } from "react-router-dom";
export default function UpdateCity(){
    const navigate=useNavigate()
    const [city,setCity]=useState()
    const [image,setImage]=useState()
    const [loading,setLoading]=useState(false)
    const param=useParams()
    const id=param.id
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    useEffect(()=>{
        setLoading(true)
        let data={
            _id:id
        }
        apiServices.getSingleCity(data).then(
            (data)=>{
                setLoading(false)
                // console.log(data.data.data.name)
                if(data.data.success){
                    toast.success(data.data.message)
                    setCity(data.data.data.name)
                    setImage(data.data.data.thumbnail)
                }
                else{
                    toast.error(data.data.message)
                }
            }
        ).catch(
            (error)=>{
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1000)
            }
        )
    },[])
    const handleForm=(e)=>{
        e.preventDefault();
        setLoading(true)
        let data=new FormData()
        data.append("name", city)
        data.append("city_image", image)
        data.append("_id",id)
        apiServices.updateCity(data).then((data)=>{
            setLoading(false)
            if(data.data.success){
                toast.success(data.data.message)
                setTimeout(()=>{
                    navigate("/admin/manage_city")
                },2000)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    }
    return(
        <>
            <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Update City</h1>
                        <div className="d-flex justify-content-center my-3">
                            <img src={BASE_URL_Image+`${image}`} style={{height:"200px"}}/>
                        </div>
                        <div className="row">
                            <div className="col-md-2 offset-md-1">
                                <label>City Name</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="text" value={city} onChange={(e)=>{setCity(e.target.value)}}/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Thumbnail</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="file"  onChange={(e)=>{setImage(e.target.files[0])}}/>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Submit</button>
                        </div>
                    </div>
                </section>
            </main>
            </div>
        </>
    )
}