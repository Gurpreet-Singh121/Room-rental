import { useState } from "react"
import apiServices from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
export default function AddReseller(){
    const [name,setName]=useState()
    const [email,setEmail]=useState()
    const [password,setPassword]=useState()
    const [contact,setContact]=useState()
    const [adhaar,setAdhaar]=useState()
    const [address,setAddress]=useState()
    const [image,setImage]=useState()
    const [loading,setLoading]=useState(false)
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    const handleForm=(e)=>{
        e.preventDefault()
        setLoading(true)
        let data=new FormData()
        data.append("name", name)
        data.append("email", email)
        data.append("password", password)
        data.append("contact",contact)
        data.append("address",address)
        data.append("aadharCardNo",adhaar)
        data.append("reseller_image", image)
        apiServices.addReseller(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
                setName("")
                setImage("")
                setContact("")
                setEmail("")
                setPassword("")
                setAddress("")
                setAdhaar("")
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    return(
        <>
            <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Add Reseller</h1>
                        <form>
                        <div className="row">
                            <div className="col-md offset-md-1 ">
                                <label>Name</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="text" value={name} onChange={(e)=>{setName(e.target.value)}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Contact</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={contact} onChange={(e)=>{setContact(e.target.value)}} required/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md offset-md-1 ">
                                <label>Email</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Password</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}} required/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md offset-md-1">
                                <label>Profile Image</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="file"  onChange={(e)=>{setImage(e.target.files[0])}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Adhaar Card</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={adhaar} onChange={(e)=>{setAdhaar(e.target.value)}} required/>
                            </div>
                        </div>
                        <div className="my-3 row">
                            <div className="col-md offset-md-1">
                                <label>Address</label>
                            </div>
                            <div className="col-md-10">
                                <textarea className="form-control" required onChange={(e)=>{setAddress(e.target.value)}}>{address}</textarea>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Submit</button>
                        </div>
                        </form>
                    </div>
                </section>
            </main>
            </div>
        </>
    )
}