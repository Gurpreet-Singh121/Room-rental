import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function ManageReseller(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const [reseller,setReseller]=useState()
    useEffect(()=>{
        apiServices.getAllReseller().then((data)=>{
            // console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setReseller(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[loading])
    const changeStatus=(id,status)=>{
        setLoading(true)
        if(status==true){
         var upstatus=false
        }
        else{
         var upstatus=true
        }
        let data={
          _id:id, 
          status:upstatus
        }
        apiServices.changeStatusReseller(data).then((data)=>{
          // console.log(data)
          setTimeout(()=>{
              setLoading(false)
          },1000)
          if(data.data.success){
              toast.success(data.data.message)
          }
          else{
              toast.error(data.data.message)
          }
      }).catch((error)=>{
          // console.log(error)
          toast.error("Something went wrong!!Try Again Later")
          setTimeout(()=>{
              setLoading(false)
          },1500)
      })
      }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Resellers</h1>
                    <div className="container my-5 table-responsive">
                        <table className="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Contact</th>
                                    <th>Adhaar Card</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Edit</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            {reseller?.map((element,index)=>(
                                <tr key={index+1}>
                                    <td>{index+1}</td>
                                    <td>
                                        <img src={BASE_URL_Image+element?.image} className="img-fluid" style={{height:"150px"}}/>
                                    </td>
                                    <td>{element?.name}</td>
                                    <td>{element?.email}</td>
                                    <td>{element?.password}</td>
                                    <td>{element?.contact}</td>
                                    <td>{element?.aadharCardNo}</td>
                                    <td>{element?.address}</td>
                                    <td>{element?.status?"Active":"In-active"}</td>
                                    <td>
                                        <Link to={`/admin/update_reseller/${element?._id}`}>
                                            <i className="bi bi-pencil-square fs-3 text-success"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <button type="submit" className='btn btn-outline-danger mx-2' onClick={()=>{changeStatus(element?._id,element?.status)}}>Change Status</button>
                                    </td>
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}