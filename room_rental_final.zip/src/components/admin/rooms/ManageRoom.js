import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function ManageRoom(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const [room,setRoom]=useState()
    useEffect(()=>{
        apiServices.getAllRoom().then((data)=>{
            // console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setRoom(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[loading])
    const changeStatus=(id,status)=>{
        setLoading(true)
        if(status==true){
         var upstatus=false
        }
        else{
         var upstatus=true
        }
        let data={
          _id:id, 
          status:upstatus
        }
        apiServices.changeStatusRoom(data).then((data)=>{
          // console.log(data)
          setTimeout(()=>{
              setLoading(false)
          },1000)
          if(data.data.success){
              toast.success(data.data.message)
          }
          else{
              toast.error(data.data.message)
          }
      }).catch((error)=>{
          // console.log(error)
          toast.error("Something went wrong!!Try Again Later")
          setTimeout(()=>{
              setLoading(false)
          },1500)
      })
      }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Rooms</h1>
                    <div className="container my-5 table-responsive">
                        <table className="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Image</th>
                                    <th>Reseller</th>
                                    <th>City</th>
                                    <th>Type</th>
                                    <th>Price</th>
                                    <th>Initial Amount</th>
                                    <th>Lease Time</th>
                                    <th>Location</th>
                                    {/* <th>Description</th> */}
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>View</th>
                                    <th>Edit</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            {room?.map((element,index)=>(
                                <tr key={index+1}>
                                    <td>{index+1}</td>
                                    <td>
                                        <img src={BASE_URL_Image+element?.image1} className="img-fluid w-100" style={{height:"150px"}}/>
                                    </td>
                                    <td>{element?.resellerId?.name}</td>
                                    <td>{element?.cityId?.name}</td>
                                    <td>{element?.roomtypeId?.name}</td>
                                    <td>&#8377; {element?.price}</td>
                                    <td>&#8377; {element?.initialamount}</td>
                                    <td>{element?.leasetime} yrs</td>
                                    <td>{element?.location}</td>
                                    {/* <td>{element?.description}</td> */}
                                    <td>{element?.address}</td>
                                    <td>{element?.status?"Active":"In-active"}</td>
                                    <td>
                                        <Link to={`/admin/view_room/${element?._id}`}>
                                            <i className="bi bi-eye fs-3 text-info"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <Link to={`/admin/update_room/${element?._id}`}>
                                            <i className="bi bi-pencil-square fs-3 text-success"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <button type="submit" className='btn btn-outline-danger mx-2' onClick={()=>{changeStatus(element?._id,element?.status)}}>Change Status</button>
                                    </td>
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}