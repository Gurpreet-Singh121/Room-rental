import { useState } from "react"
import apiServices from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import { useEffect } from "react"
export default function AddRoom(){
    const [resellerId,setResellerId]=useState()
    const [allReseller,setAllReseller]=useState()
    const [allRoomType,setAllRoomType]=useState()
    const [allCity,setAllCity]=useState()
    const [city,setCity]=useState()
    const [roomTypeId,setRoomTypeId]=useState()
    const [price,setPrice]=useState()
    const [leaseTime,setLeaseTime]=useState()
    const [initialAmount,setInitialAmount]=useState()
    const [address,setAddress]=useState()
    const [description,setDescription]=useState()
    const [location,setLocation]=useState()
    const [image,setImage]=useState()
    const [image1,setImage1]=useState()
    const [loading,setLoading]=useState(false)
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    useEffect(()=>{
        setLoading(true)
        let data={
            status: true,
        }
        apiServices.getAllRoomType(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setAllRoomType(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        })
        apiServices.getAllReseller(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setAllReseller(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        })
        apiServices.getAllCity(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setAllCity(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        })
    },[])
    const handleForm=(e)=>{
        e.preventDefault();
        let data=new FormData();
        data.append("resellerId",resellerId)
        data.append("roomtypeId",roomTypeId)
        data.append("cityId",city)
        data.append("address",address)
        data.append("location",location)
        data.append("description",description)
        data.append("price",price)
        data.append("leasetime",leaseTime)
        data.append("initialamount",initialAmount)
        data.append("room_image1",image)
        data.append("room_image2",image1)
        apiServices.addRoom(data).then((data)=>{
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
                setPrice("")
                setRoomTypeId("")
                setResellerId("")
                setCity("")
                setImage("")
                setAddress("")
                setImage1("")
                setLocation("")
                setDescription("")
                setInitialAmount("")
                setLeaseTime("")
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1500)
        })
    }
    return(
    <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Add Reseller</h1>
                        <form>
                        <div className="row">
                            <div className="col-md offset-md-1 ">
                                <label>Reseller</label>
                            </div>
                            <div className="col-md-4">
                                <select className="form-control" required onChange={(e)=>{setResellerId(e.target.value)}}>
                                    <option>Select Reseller</option>
                                    {allReseller?.map((el,index)=>(
                                        <option key={index} value={el?._id}>{el?.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Type</label>
                            </div>
                            <div className="col-md-4">
                                <select  required className="form-control"
                                onChange={(e)=>{setRoomTypeId(e.target.value)}}>
                                    <option>Select Type</option>
                                    {allRoomType?.map((el,index)=>(
                                        <option key={index} value={el?._id}>{el?.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div className="row my-3">  
                            <div className="col-md offset-md-1 ">
                                <label>City</label>
                            </div>
                            <div className="col-md-4">
                                <select className="form-control" required onChange={(e)=>{setCity(e.target.value)}}>
                                    <option>Select City</option>
                                    {allCity?.map((el,index)=>(
                                        <option key={index} value={el?._id}>{el?.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Lease Time</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={leaseTime} onChange={(e)=>{setLeaseTime(e.target.value)}} placeholder="Enter Lease Time in years" required/>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md offset-md-1">
                                <label>Location</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="text" value={location} onChange={(e)=>{setLocation(e.target.value)}} placeholder="Enter Location" required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Address</label>
                            </div>
                            <div className="col-md-4">
                                <textarea required className="form-control" rows="1"  onChange={(e)=>{setAddress(e.target.value)}}>{address}</textarea>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md offset-md-1">
                                <label>Price</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" value={price}  type="number"  onChange={(e)=>{setPrice(e.target.value)}} placeholder="Enter Total Price" required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Initial Amount</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="number" value={initialAmount} onChange={(e)=>{setInitialAmount(e.target.value)}} placeholder="Enter Initial Amount to book" required/>
                            </div>
                        </div>
                        <div className="my-3 row">
                            <div className="col-md offset-md-1">
                                <label>Image 1</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="file" onChange={(e)=>{setImage(e.target.files[0])}} required/>
                            </div>
                            <div className="col-md offset-md-1">
                                <label>Image 2</label>
                            </div>
                            <div className="col-md-4">
                                <input className="form-control" type="file" onChange={(e)=>{setImage1(e.target.files[0])}} required/>
                            </div>
                        </div>
                        <div className="my-3 row">
                            <div className="col-md offset-md-1">
                                <label>Description</label>
                            </div>
                            <div className="col-md-10">
                                <textarea className="form-control" required onChange={(e)=>{setDescription(e.target.value)}}>{description}</textarea>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Submit</button>
                        </div>
                        </form>
                    </div>
                </section>
            </main>
        </div>
    </>
    )
}