import { useEffect, useState } from "react"
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import {toast} from "react-toastify";
import { ClipLoader } from 'react-spinners';
import { useNavigate, useParams } from "react-router-dom";
export default function UpdateRoomType(){
    const navigate=useNavigate()
    const [name,setName]=useState()
    const [loading,setLoading]=useState(false)
    const param=useParams()
    const id=param.id
    const override={
        "display":"block",
        "margin":"0 auto",
        "position":"absolute",
        "top":"35%",
        "zIndex":"1",
    }
    useEffect(()=>{
        setLoading(true)
        let data={
            _id:id
        }
        apiServices.getSingleRoomType(data).then(
            (data)=>{
                setLoading(false)
                // console.log(data.data.data.name)
                if(data.data.success){
                    toast.success(data.data.message)
                    setName(data.data.data.name)
                }
                else{
                    toast.error(data.data.message)
                }
            }
        ).catch(
            (error)=>{
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1000)
            }
        )
    },[])
    const handleForm=(e)=>{
        e.preventDefault();
        setLoading(true)
        let data={
            _id:id,
            name:name
        }
        apiServices.updateRoomType(data).then((data)=>{
            setLoading(false)
            if(data.data.success){
                toast.success(data.data.message)
                setTimeout(()=>{
                    navigate("/admin/manage_room_type")
                },2000)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            toast.error("Something went wrong")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    }
    return(
        <>
            <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
            <main id="main">
                <section className="intro-single">
                    <div className="container border border-success border-2 rounded pt-3">
                        <h1 className="text-center text-success">Update Type</h1>
                        <div className="row my-3">
                            <div className="col-md-2 offset-md-1">
                                <label>Type Name</label>
                            </div>
                            <div className="col-md-8">
                                <input className="form-control" type="text" value={name} onChange={(e)=>{setName(e.target.value)}}/>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center my-3">
                            <button className="btn btn-outline-success btn-lg w-25 mb-4" onClick={handleForm}>Submit</button>
                        </div>
                    </div>
                </section>
            </main>
            </div>
        </>
    )
}