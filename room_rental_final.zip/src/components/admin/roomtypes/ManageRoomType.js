import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function ManageRoomType(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const [name,setName]=useState()
    useEffect(()=>{
        apiServices.getAllRoomType().then((data)=>{
            // console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setName(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[loading])
    const changeStatus=(id,status)=>{
        setLoading(true)
        if(status==true){
         var upstatus=false
        }
        else{
         var upstatus=true
        }
        let data={
          _id:id, 
          status:upstatus
        }
        apiServices.changeStatusRoomType(data).then((data)=>{
          // console.log(data)
          setTimeout(()=>{
              setLoading(false)
          },1000)
          if(data.data.success){
              toast.success(data.data.message)
          }
          else{
              toast.error(data.data.message)
          }
      }).catch((error)=>{
          // console.log(error)
          toast.error("Something went wrong!!Try Again Later")
          setTimeout(()=>{
              setLoading(false)
          },1500)
      })
      }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Room Types</h1>
                    <div className="container my-5 table-responsive">
                        <table className="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Type Name</th>
                                    <th>Status</th>
                                    <th>Edit</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            {name?.map((element,index)=>(
                                <tr key={index+1}>
                                    <td>{index+1}</td>
                                    <td>{element?.name}</td>
                                    <td>{element?.status?"Active":"In-active"}</td>
                                    <td>
                                        <Link to={`/admin/update_room_type/${element?._id}`}>
                                            <i className="bi bi-pencil-square fs-3 text-success"></i>
                                        </Link>
                                    </td>
                                    <td>
                                        <button type="submit" className='btn btn-outline-danger mx-2' onClick={()=>{changeStatus(element?._id,element?.status)}}>Change Status</button>
                                    </td>
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}