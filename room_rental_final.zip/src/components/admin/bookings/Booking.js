import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import apiServices, { BASE_URL_Image } from "../../../services/apiServices";
import { ClipLoader } from "react-spinners"
export default function Booking(){
    const [loading,setLoading]=useState(true)
    const override={
        "position":'absolute',
        "display":"block",
        "top":"35%", 
        "zIndex":"1",
    }
    const navigate=useNavigate()
    const [booking,setBooking]=useState()
    useEffect(()=>{
        apiServices.userBooking().then((data)=>{
            console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                setBooking(data.data.data)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    },[booking])
    const acceptBook=(id)=>{
        setLoading(true)
            let data={
                _id:id,
                bookingStatus:"approved"
            }
            apiServices.updateBooking(data).then((data)=>{
                console.log(data)
                setTimeout(()=>{
                    setLoading(false)
                },1500)
                if(data.data.success){
                    toast.success(data.data.message)
                }
                else{
                    toast.error(data.data.message)
                }
            }).catch((error)=>{
                // console.log(error)
                toast.error("Something went wrong!!Try Again Later")
                setTimeout(()=>{
                    setLoading(false)
                },1000)
            })
    }
    const rejectBook=(id)=>{
        setLoading(true)
        let data={
            _id:id,
            bookingStatus:"declined"
        }
        apiServices.updateBooking(data).then((data)=>{
            console.log(data)
            setTimeout(()=>{
                setLoading(false)
            },1500)
            if(data.data.success){
                toast.success(data.data.message)
            }
            else{
                toast.error(data.data.message)
            }
        }).catch((error)=>{
            // console.log(error)
            toast.error("Something went wrong!!Try Again Later")
            setTimeout(()=>{
                setLoading(false)
            },1000)
        })
    }
    return(
        <>
         <div className="d-flex justify-content-center">
            <ClipLoader loading={loading} cssOverride={override} size={120}/>
        </div>
        <div className={loading?"disabled-screen-full":""}>   
        <main id="main">
            <section className="intro-single">
                <div className="container border border-success border-2 rounded pt-3">
                    <h1 className="text-center text-success">Rooms</h1>
                    <div className="container my-5 table-responsive">
                        <table className="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Image</th>
                                    {/* <th>Reseller</th>
                                    <th>City</th> */}
                                    {/* <th>Type</th> */}
                                    <th>Price</th>
                                    <th>Initial Amount</th>
                                    <th>Lease Time</th>
                                    <th>Location</th>
                                    <th>Address</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            {booking?.map((element,index)=>(
                                <tr key={index+1}>
                                    <td>{index+1}</td>
                                    <td>
                                        <img src={BASE_URL_Image+element?.roomId?.image1} className="img-fluid w-100" style={{height:"150px"}}/>
                                    </td>
                                    {/* <td>{element?.resellerId?.name}</td>
                                    <td>{element?.cityId?.name}</td> */}
                                    {/* <td>{element?.roomtypeId?.name}</td> */}
                                    <td>&#8377; {element?.roomId?.price}</td>
                                    <td>&#8377; {element?.roomId?.initialamount}</td>
                                    <td>{element?.roomId?.leasetime} yrs</td>
                                    <td>{element?.roomId?.location}</td>
                                    {/* <td>{element?.description}</td> */}
                                    <td>{element?.roomId?.address}</td>
                                    <td>{element?.date}</td>
                                    {element?.bookingStatus=='pending'?
                                    <td>
                                    <button className="btn btn-sm btn-success"   onClick={()=>{acceptBook(element?._id)}}>ACCEPT</button><button   onClick={()=>{rejectBook(element?._id)}} className="btn btn-sm  btn-danger">Decline</button>
                                    </td>
                                    :<td>{element?.bookingStatus}</td>
                                    }
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </section>
        </main>
        </div>
        </>
    )
}