import { Link } from "react-router-dom"
import apiServices, { BASE_URL_Image } from "../services/apiServices"
import {toast} from "react-toastify"
import { useEffect, useState } from "react"

export default function Main(){
    const [room,setRoom]=useState()
    useEffect(()=>{
        var data={
            status:true
        }
    apiServices.getAllRoom(data).then((data)=>{
        console.log(data)
        if(data.data.success){
            setRoom(data.data.data)
        }
        else{
            toast.error(data.data.message)
        }
    }).catch((error)=>{
        // console.log(error)
        toast.error("Something went wrong!!Try Again Later")
    })
},[])
    return(
        <>
            {/* <!-- ======= Intro Section ======= --> */}
            <div className="intro intro-carousel swiper position-relative">

                <div className="swiper-wrapper">

                <div className="swiper-slide carousel-item-a intro-item bg-image" style={{backgroundImage: 'url(assets/img/slide-1.jpg)'}}>
                    <div className="overlay overlay-a"></div>
                    <div className="intro-content display-table">
                    <div className="table-cell">
                        <div className="container">
                        <div className="row">
                            <div className="col-lg-8">
                            <div className="intro-body">
                                <p className="intro-title-top">Chandigarh,Punjab
                                <br/> 78345
                                </p>
                                <h1 className="intro-title mb-4 ">
                                <span className="color-b">204 </span> Mount
                                <br/> Olive Road Two
                                </h1>
                                <p className="intro-subtitle intro-price">
                                <a href="#"><span className="price-a">House of Your Dreams</span></a>
                                </p>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="swiper-slide carousel-item-a intro-item bg-image" style={{backgroundImage: 'url(assets/img/slide-2.jpg)'}}>
                    <div className="overlay overlay-a"></div>
                    <div className="intro-content display-table">
                    <div className="table-cell">
                        <div className="container">
                        <div className="row">
                            <div className="col-lg-8">
                            <div className="intro-body">
                                <p className="intro-title-top">Model Town
                                <br/> Jalandhar
                                </p>
                                <h1 className="intro-title mb-4">
                                <span className="color-b">204 </span> Amritsar
                                <br/> Venda Road Five
                                </h1>
                                <p className="intro-subtitle intro-price">
                                <a href="#"><span className="price-a">rent | Rs.15k</span></a>
                                </p>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="swiper-slide carousel-item-a intro-item bg-image" style={{backgroundImage:'url(assets/img/slide-3.jpg)'}}>
                    <div className="overlay overlay-a"></div>
                    <div className="intro-content display-table">
                    <div className="table-cell">
                        <div className="container">
                        <div className="row">
                            <div className="col-lg-8">
                            <div className="intro-body">
                                <p className="intro-title-top">Doral, Florida
                                <br/> 78345
                                </p>
                                <h1 className="intro-title mb-4">
                                <span className="color-b">204 </span> Alira
                                <br/> Roan Road One
                                </h1>
                                <p className="intro-subtitle intro-price">
                                <a href="#"><span className="price-a">rent | $ 12.000</span></a>
                                </p>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
                <div className="swiper-pagination"></div>
            </div>
            {/* <!-- End Intro Section --> */}
            <div className="container-fluid border border-success border-2 p-5 rounded pt-3">
                    <h1 className="text-center text-success">Property</h1>
                    <div className="row">
                        {room?.slice(0,6)?.map((el,index)=>(
                                <div className="col-md-4 my-3 p-3" key={index}>
                                <Link to={`/user/view_room/${el?._id}`}>
                                <div className="card text-center p-4" style={{maxHeight:"600px"}}>
                                    <img src={BASE_URL_Image+`${el?.image1}`} className="card-img-top" style={{height:"260px"}}/>
                                    <h3 className="card-text">
                                    {el?.roomtypeId?.name}
                                    <br/>
                                    {el?.location},
                                    {el?.address} 
                                    </h3>
                                    <h3>Price- &#8377; {el?.price}</h3>
                                    <h4 className="card-text">Booking Amount- &#8377; {el?.initialamount}</h4>
                                    <p className="card-text">Lease Time- {el?.leasetime} years</p>
                                    <Link to={"/user/single_room/"+`${el?._id}`}>
                                    <button className="btn btn-outline-success">View More</button>
                                    </Link>
                                    {/* <p className="card-text" style={{overflow:"hidden",height:"100px"}}>{el?.description}</p> */}
                                </div>
                                </Link>
                            </div>
                        ))}
                    </div>
                    <div className="d-flex my-3  justify-content-center">
                        <Link to="/user/view_room">
                        <button className="btn btn-outline-success rounded-pill">View More</button>
                        </Link>
                    </div>
                </div>
            <main id="main">

                {/* <!-- ======= Services Section ======= --> */}
                <section className="section-services section-t8">
                <div className="container">
                    <div className="row">
                    <div className="col-md-12">
                        <div className="title-wrap d-flex justify-content-between">
                        <div className="title-box">
                            <h2 className="title-a">Our Services</h2>
                        </div>
                        </div>
                    </div>
                    </div>
                    <div className="row">
                    <div className="col-md-4">
                        <div className="card-box-c foo">
                        <div className="card-header-c d-flex">
                            <div className="card-box-ico">
                            <span className="bi bi-cart"></span>
                            </div>
                            <div className="card-title-c align-self-center">
                            <h2 className="title-c">Rooms</h2>
                            </div>
                        </div>
                        <div className="card-body-c">
                            <p className="content-c">
                            Get Best rooms and property at affordable prices
                            </p>
                        </div>
                        <div className="card-footer-c">
                        <Link to="/user/view_room">
                            <a href="#" className="link-c link-icon">Read more
                            <span className="bi bi-chevron-right"></span>
                            </a>
                            </Link>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card-box-c foo">
                        <div className="card-header-c d-flex">
                            <div className="card-box-ico">
                            <span className="bi bi-calendar4-week"></span>
                            </div>
                            <div className="card-title-c align-self-center">
                            <h2 className="title-c">Types</h2>
                            </div>
                        </div>
                        <div className="card-body-c">
                            <p className="content-c">
                            Get Your Requirement filled with many Types
                            </p>
                        </div>
                        <div className="card-footer-c">
                        <Link to="/user/view_type">
                            <a href="#" className="link-c link-icon">Check Type
                            <span className="bi bi-calendar4-week"></span>
                            </a>
                            </Link>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card-box-c foo">
                        <div className="card-header-c d-flex">
                            <div className="card-box-ico">
                            <span className="bi bi-card-checklist"></span>
                            </div>
                            <div className="card-title-c align-self-center">
                            <h2 className="title-c">City</h2>
                            </div>
                        </div>
                        <div className="card-body-c">
                            <p className="content-c">
                           Get Rooms of Your Dreams in your city
                            </p>
                        </div>
                        <div className="card-footer-c">
                            <Link to="/user/view_city">
                            <a href="#" className="link-c link-icon">Check City
                            <span className="bi bi-chevron-right"></span>
                            </a>
                            </Link>
                            
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </section>
                {/* <!-- End Services Section --> */}
                {/* <!-- ======= Agents Section ======= --> */}
                <section className="section-agents section-t8">
                <div className="container">
                    <div className="row">
                    <div className="col-md-12">
                        <div className="title-wrap d-flex justify-content-between">
                        <div className="title-box">
                            <h2 className="title-a">Best Agents</h2>
                        </div>
                        <div className="title-link">
                            <a href="agents-grid.html">All Agents
                            <span className="bi bi-chevron-right"></span>
                            </a>
                        </div>
                        </div>
                    </div>
                    </div>
                    <div className="row">
                    <div className="col-md-4">
                        <div className="card-box-d">
                        <div className="card-img-d">
                            <img src="assets/img/agent-4.jpg" alt="" className="img-d img-fluid"/>
                        </div>
                        <div className="card-overlay card-overlay-hover">
                            <div className="card-header-d">
                            <div className="card-title-d align-self-center">
                                <h3 className="title-d">
                                <a href="agent-single.html" className="link-two">Margaret Sotillo
                                    <br/> Escala</a>
                                </h3>
                            </div>
                            </div>
                            <div className="card-body-d">
                            <p className="content-d color-text-a">
                                Home Rental for renting of houses and flats
                            </p>
                            <div className="info-agents color-a">
                                <p>
                                <strong>Phone: </strong> +91-8979879333
                                </p>
                                <p>
                                <strong>Email: </strong> agents@home-rental.com
                                </p>
                            </div>
                            </div>
                            <div className="card-footer-d">
                            <div className="socials-footer d-flex justify-content-center">
                                <ul className="list-inline">
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-facebook" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-twitter" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-instagram" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-linkedin" aria-hidden="true"></i>
                                    </a>
                                </li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card-box-d">
                        <div className="card-img-d">
                            <img src="assets/img/agent-1.jpg" alt="" className="img-d img-fluid"/>
                        </div>
                        <div className="card-overlay card-overlay-hover">
                            <div className="card-header-d">
                            <div className="card-title-d align-self-center">
                                <h3 className="title-d">
                                <a href="agent-single.html" className="link-two">Sujal 
                                    <br/> kumar</a>
                                </h3>
                            </div>
                            </div>
                            <div className="card-body-d">
                            <p className="content-d color-text-a">
                            Home Rental for renting of houses and flats
                            </p>
                            <div className="info-agents color-a">
                                <p>
                                <strong>Phone: </strong> +91-9837874342
                                </p>
                                <p>
                                <strong>Email: </strong> agents@home-rental.com
                                </p>
                            </div>
                            </div>
                            <div className="card-footer-d">
                            <div className="socials-footer d-flex justify-content-center">
                                <ul className="list-inline">
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-facebook" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-twitter" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-instagram" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-linkedin" aria-hidden="true"></i>
                                    </a>
                                </li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="card-box-d">
                        <div className="card-img-d">
                            <img src="assets/img/agent-5.jpg" alt="" className="img-d img-fluid"/>
                        </div>
                        <div className="card-overlay card-overlay-hover">
                            <div className="card-header-d">
                            <div className="card-title-d align-self-center">
                                <h3 className="title-d">
                                <a href="agent-single.html" className="link-two">Vineet
                                    <br/>Sharma </a>
                                </h3>
                            </div>
                            </div>
                            <div className="card-body-d">
                            <p className="content-d color-text-a">
                            Home Rental for renting of houses and flats
                            </p>
                            <div className="info-agents color-a">
                                <p>
                                <strong>Phone: </strong> ++91-8978374322
                                </p>
                                <p>
                                <strong>Email: </strong> agents@home-rental.com
                                </p>
                            </div>
                            </div>
                            <div className="card-footer-d">
                            <div className="socials-footer d-flex justify-content-center">
                                <ul className="list-inline">
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-facebook" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-twitter" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-instagram" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="list-inline-item">
                                    <a href="#" className="link-one">
                                    <i className="bi bi-linkedin" aria-hidden="true"></i>
                                    </a>
                                </li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </section>
                {/* <!-- End Agents Section --> */}
            </main>
            {/* <!-- End #main --> */}
        </>
    )
}